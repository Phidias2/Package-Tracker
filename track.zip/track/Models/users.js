const mongoose = require ('mongoose');
const Schema = mongoose.Schema;

const UserSchema = new Schema ({
    username: {
        type: String,
        unique: true,
        minLength: 3,
        maxLength: 15,
        require: [true, "Username is required"],
    },

    nom: {
        type: String,
        require: [true, "Nom is required"],
    },

    prenom: {
        type: String,
        require: [true, "Prenom is require"],
    },

    email: {
        type: String,
        unique: true,
        require: [true, "Email is required"],
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/,"Invalide email address"],
    },

    password: {
        type: String,
        require: true,
     },

    code: {
        type: String,
        require: false,
    },

    profil_picture: {
        type: String,
        require: false,
    },

    created_at: {
        type: Date,
        require: false,
    },

    is_deleted: {
        type: Date,
        require: false,
    },

    is_active: {
        type: Boolean,
        require: true,
    },

    role: {
        type: String,
        require: true,
    }
});
module.exports = mongoose.model("Users",UserSchema);