const mongoose = require ('mongoose');
const Schema = mongoose.Schema;

const RoleSchema = new Schema ({
    label : {
        type: String,
        require: true,
    },

    created_at : {
        type: Date,
        require: true,
    }
});
module.exports = mongoose.model("Roles",RoleSchema);