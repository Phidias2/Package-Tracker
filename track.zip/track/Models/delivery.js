const mongoose = require ('mongoose');
const { softDeletePlugin } = require('soft-delete-plugin-mongoose');
const Schema = mongoose.Schema;

const DeliverySchema = new Schema ({

    delivery_id: {
        type: String,
        required: true
    },

    package_id: {
        type: String,
        required: true,
        ref: 'Packages'
    },

    pickup_time: {
        type: Date,
        require: false,
    },

    start_time: {
        type: Date,
        require: false,
    },

    end_time: {
        type: Date,
        require: false,
    },

    location: {
        type: Object,
        require: false,
    },

    status: {
        type: String,
        enum: ['open', 'picked-up', 'in-transit', 'delivered', 'failed'],
        require: false,
    },
});

DeliverySchema.plugin(softDeletePlugin);
module.exports = mongoose.model("Delivery",DeliverySchema);