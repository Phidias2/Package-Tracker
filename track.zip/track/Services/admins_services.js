const express = require('express');
const router = express.Router();
const userModel = require('../Models/users');
const verifyToken = require('../middlewares/middleware');



module.exports = router;