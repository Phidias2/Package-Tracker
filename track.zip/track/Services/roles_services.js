const express = require('express');
const router = express.Router();
const roleModels = require('../Models/role');
const verifyToken = require('../Middlewares/middleware');


router.post('/supAd',verifyToken,async(req,res)=>{
    const roleName = "SuperAdmin";
    const result = await roleModels.findOne({label:roleName}).exec();
    if(result){
        res.send({status:404,message:"Role already exists !"});
    } else {
        role = new roleModels ({
            label : "SuperAdmin",
            created_at : new Date(),
        });
        await role.save();
        res.send({status:201,role});
    }
});

router.post('/addRole',verifyToken,async(req,res)=>{
    if(!req.user)
    {
        res.send({status:404,message: "Invalide Token"});
    }else {
    if (req.user.role == "SuperAdmin")
    {
        const name = req.body.name.toLowerCase();
        const result = await roleModels.findOne({label:name}).exec();
        if(result)
        {
            res.send({status:404,message:"Role already exists !"});

        } else {
            role = new roleModels({
                label : name,
                created_at : new Date(),
            });
            await role.save();
            res.send({status:201,role});
        }
    }
        else 
        {
            res.send({status:404,message:"Not authorise"});
        };
}
});

router.get('/allRole',async(req,res)=>{
    const result = await roleModels.find().exec();
    res.send({status:200, result});
});

router.get('/findRole/:name',verifyToken,async(req,res)=>{
    if(!req.user)
    {
        res.send({status:404,message: "Invalide Token"});
    }else {
    if (req.user.role == "SuperAdmin")
    {
        const role = req.params.name;
        const result = await roleModels.findOne({label: role}).exec();
        res.send({status:200,result});
    }
    else 
    {
        res.send({status:401,message:"Not authorise"});
    };
}
});


router.put('/modifyRole/:name',async,async(req,res)=>{
    if(!req.user)
    {
        res.send({status:404,message: "Invalide Token"});
    }else {
    if (req.user.role == "SuperAdmin")
    {
        const role = req.params.name;
        const newLabel = req.body.label;
        const result = await roleModels.findOneAndUpdate({label: role},{label: newLabel}).exec();
        res.send({status:200,result});
    }
    else 
    {
        res.send({status:401,message:"Not authorise"});
    };
}
});

router.delete('/deleteRole/:name',verifyToken,async(req,res)=>{
    if(!req.user)
    {
        res.send({status:404,message: "Invalide Token"});
    }else {
    if (req.user.role == "SuperAdmin")
    {
        const name = req.params.name;
        await roleModels.findOneAndDelete({label: name}).exec();
        res.send({status:200,message:"Delete with sucess"});
    }
    else 
    {
        res.send({status:401,message:"Not authorise"});
    };
}
});
module.exports = router;